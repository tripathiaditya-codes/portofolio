import React from 'react';
import { Github, Linkedin, Mail, ExternalLink, Code2, Boxes, User2 } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <header className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
              Aditya Tripathi
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 mb-8">
              Full Stack Web Developer
            </p>
            <div className="flex justify-center gap-4">
              <a href="https://github.com/tripathiaditya-codes" target="_blank" rel="noopener noreferrer" 
                className="p-2 text-gray-600 hover:text-gray-900 transition-colors">
                <Github size={24} />
              </a>
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer"
                className="p-2 text-gray-600 hover:text-gray-900 transition-colors">
                <Linkedin size={24} />
              </a>
              <a href="mailto:contact@example.com"
                className="p-2 text-gray-600 hover:text-gray-900 transition-colors">
                <Mail size={24} />
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* About Section */}
      <section className="py-20 bg-white" id="about">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center gap-2 mb-8">
              <User2 className="text-indigo-600" />
              <h2 className="text-3xl font-bold text-gray-900">About Me</h2>
            </div>
            <p className="text-lg text-gray-600 mb-6">
              I'm a passionate full-stack developer with expertise in modern web technologies.
              I specialize in building scalable web applications using React, Node.js, and
              cutting-edge tools in the JavaScript ecosystem.
            </p>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section className="py-20 bg-gray-50" id="skills">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center gap-2 mb-8">
              <Code2 className="text-indigo-600" />
              <h2 className="text-3xl font-bold text-gray-900">Skills</h2>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
              {['React', 'TypeScript', 'Node.js', 'Next.js', 'TailwindCSS', 'PostgreSQL'].map((skill) => (
                <div key={skill} className="bg-white p-4 rounded-lg shadow-sm">
                  <p className="text-lg font-medium text-gray-800">{skill}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section className="py-20 bg-white" id="projects">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center gap-2 mb-8">
              <Boxes className="text-indigo-600" />
              <h2 className="text-3xl font-bold text-gray-900">Projects</h2>
            </div>
            <div className="grid md:grid-cols-2 gap-8">
              {[
                {
                  title: 'E-Commerce Platform',
                  description: 'A full-stack e-commerce solution built with React and Node.js',
                  image: 'https://images.unsplash.com/photo-1661956602116-aa6865609028?auto=format&fit=crop&q=80&w=800',
                },
                {
                  title: 'Task Management App',
                  description: 'A real-time task management application using React and WebSocket',
                  image: 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?auto=format&fit=crop&q=80&w=800',
                }
              ].map((project, index) => (
                <div key={index} className="bg-gray-50 rounded-lg overflow-hidden shadow-sm">
                  <img src={project.image} alt={project.title} className="w-full h-48 object-cover" />
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{project.title}</h3>
                    <p className="text-gray-600 mb-4">{project.description}</p>
                    <a href="#" className="inline-flex items-center text-indigo-600 hover:text-indigo-700">
                      View Project <ExternalLink size={16} className="ml-1" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-gray-400">© 2024 Aditya Tripathi. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;